package com.example.it4410assignment4;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.StringJoiner;

public class MainActivity extends AppCompatActivity {


    /* ------------------------------------
     * -              TEST                -
     * -   DO NOT CHANGE THE CODE BELOW   -
     * ------------------------------------
     */
    /** problem 1 */
    private String[] problem1Test = {"Hello world", "Goodbye world", "see you world"};
    private ArrayList<String> problem1Ans = new ArrayList<>(Arrays.asList(problem1Test));
    /** problem 2 */
    private String[] problem2TestSourceA = {"a", "b", "c"};
    private String[] problem2TestSourceB = {"c", "b", "a"};
    private ArrayList<String> problem2TestA = new ArrayList<>(Arrays.asList(problem2TestSourceA));
    private ArrayList<String> problem2TestB = new ArrayList<>(Arrays.asList(problem2TestSourceB));
    /** problem 3 */
    private Integer[] problem3SourceATest = {1, 2, 2, 2, 3, 4, 5};
    private Integer[] problem3SourceBTest = {1, 2, 3, 4, 5};
    private ArrayList<Integer> problem3Test = new ArrayList<>(Arrays.asList(problem3SourceATest));
    private ArrayList<Integer> problem3Ans = new ArrayList<>(Arrays.asList(problem3SourceBTest));
    /** problem 4 */
    private HashSet<String> problem4TestA = new HashSet<String>() {{
        add("a");
        add("b");
        add("c");
        add("d");
    }};
    private HashSet<String> problem4TestB = new HashSet<String>() {{
        add("c");
        add("b");
        add("a");
        add("f");
    }};
    private HashSet<String> problem4Ans = new HashSet<String>() {{
        add("c");
        add("b");
        add("a");
    }};
    /** problem 5 */
    private HashSet<Integer> problem5TestA = new HashSet<Integer>() {{
        add(2);
        add(3);
        add(6);
    }};
    private HashSet<Integer> problem5TestB = new HashSet<Integer>() {{
        add(7);
        add(1);
        add(9);
    }};
    private HashSet<Integer> problem5Ans = new HashSet<Integer>() {{
        add(7);
        add(1);
        add(9);
        add(2);
        add(3);
        add(6);
    }};
    /** problem 6 */
    private HashSet<Integer> problem6Test = new HashSet<Integer>() {{
        add(1);
        add(2);
        add(3);
        add(4);
        add(5);
    }};
    private double problem6Ans = 3.00;
    /** problem 7 */
    private Integer problem7Value = 20;
    private String problem7Key = "pepsi";
    private Map<String, Integer> problem7Test = new HashMap<String, Integer>() {{
        put("coke", 5);
        put("pepsi", 10);
    }};
    private Map<String, Integer> problem7Ans = new HashMap<String, Integer>() {{
        put("coke", 5);
        put("pepsi", 20);
    }};
    /** problem 8 */
    private String[][] problem8Test = {{"PUBG", "Bluehole"}, {"Dota 2", "Valve"}, {"LOL", "Riot"}};
    private Map<String, String> problem8Ans = new HashMap<String, String>() {{
        put("PUBG", "Bluehole");
        put("Dota 2", "Valve");
        put("LOL", "Riot");
    }};
    /** bonus */
    private String[][] problemBonusTest = {{"hello", "bye"}, {"this is good", "this is bad"}, {"do it", "did it"}, {"you never like it", "I never hate it"}, {"done", ""}};
    private String[][] problemBonusAns = {{"hello", "bye"}, {"good", "bad"}, {"do", "did"}, {"you", "I", "like", "hate"}, {"done"}};

    private double problem1Score = 0.0;
    private double problem2Score = 0.0;
    private double problem3Score = 0.0;
    private double problem4Score = 0.0;
    private double problem5Score = 0.0;
    private double problem6Score = 0.0;
    private double problem7Score = 0.0;
    private double problem8Score = 0.0;
    private double problemBonusScore = 0.0;
    private ArrayList<Double> scoreList = new ArrayList<>();

    private TextView problem1TextView;
    private TextView problem2TextView;
    private TextView problem3TextView;
    private TextView problem4TextView;
    private TextView problem5TextView;
    private TextView problem6TextView;
    private TextView problem7TextView;
    private TextView problem8TextView;
    private TextView problemBonusTextView;
    private TextView totalScoreTextView;
    private Button runButton;

    JavaCollections javaCollections = new JavaCollections();

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        runButton = findViewById(R.id.runButton);
        problem1TextView = findViewById(R.id.problem1TextView);
        problem2TextView = findViewById(R.id.problem2TextView);
        problem3TextView = findViewById(R.id.problem3TextView);
        problem4TextView = findViewById(R.id.problem4TextView);
        problem5TextView = findViewById(R.id.problem5TextView);
        problem6TextView = findViewById(R.id.problem6TextView);
        problem7TextView = findViewById(R.id.problem7TextView);
        problem8TextView = findViewById(R.id.problem8TextView);
        problemBonusTextView = findViewById(R.id.problemBonusTextView);
        totalScoreTextView = findViewById(R.id.totalScoreTextView);

        resetScore();

        // Button Click
        runButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                testOne();
                problem1TextView.setText(String.format("Problem 1 score: %.1f/12.5", problem1Score));

                testTwo();
                problem2TextView.setText(String.format("Problem 2 score: %.1f/12.5", problem2Score));

                testThree();
                problem3TextView.setText(String.format("Problem 3 score: %.1f/12.5", problem3Score));

                testFour();
                problem4TextView.setText(String.format("Problem 4 score: %.1f/12.5", problem4Score));

                testFive();
                problem5TextView.setText(String.format("Problem 5 score: %.1f/12.5", problem5Score));

                testSix();
                problem6TextView.setText(String.format("Problem 6 score: %.1f/12.5", problem6Score));

                testSeven();
                problem7TextView.setText(String.format("Problem 7 score: %.1f/12.5", problem7Score));

                testEight();
                problem8TextView.setText(String.format("Problem 8 score: %.1f/12.5", problem8Score));

                testBonus();
                problemBonusTextView.setText(String.format("Problem bonus score: %.1f/10.0", problemBonusScore));
                //double totalScore = scoreList.stream().mapToDouble(s -> s).sum();
                totalScoreTextView.setText(String.format("Total Score: %.1f/100.0", getTotalScore()));

                runButton.setEnabled(false);
            }
        });
    }

    private void addProblem1Answers() {

    }

    private double getTotalScore() {
        double totalScore = 0.0;
        for (double score : scoreList) {
            totalScore += score;
        }
        return totalScore;
    }

    private void resetScore() {
        problem1Score = 0.0;
        problem2Score = 0.0;
        problem3Score = 0.0;
        problem4Score = 0.0;
        problem5Score = 0.0;
        problem6Score = 0.0;
        problem7Score = 0.0;
        problem8Score = 0.0;
        problemBonusScore = 0.0;
        scoreList.removeAll(scoreList);
    }

    // Problem 1 Test
    private void testOne() {
        String[] temp = problem1Test.clone();
        if (new HashSet<>(Arrays.asList(problem1Ans)).equals(new HashSet<>(Arrays.asList(javaCollections.createArrayListFromArray(temp))))) {
            problem1Score += 12.5;
        } else {
            Log.e("Problem 1", String.format("Input: %s. Expected Output: %s. Actual output: %s", Arrays.toString(problem1Test), String.join(", ", problem1Ans), String.join(", ", javaCollections.createArrayListFromArray(problem1Test))));
        }
        scoreList.add(problem1Score);
    }

    // Problem 2 Test
    private void testTwo() {
        ArrayList<String> temp1 = new ArrayList<>(problem2TestA);
        ArrayList<String> temp2 = new ArrayList<>(problem2TestB);
        if (javaCollections.sameElementsOfTwoLists(temp1, temp2) == true) {
            problem2Score += 12.5;
        } else {
            Log.e("Problem 2", String.format("Input: %s and %s. Expected Output: True. Actual output: False", String.join(", ", problem2TestA), String.join(", ", problem2TestB)));
        }
        scoreList.add(problem2Score);
    }

    // Problem 3 Test
    private void testThree() {
        ArrayList<Integer> temp = new ArrayList<>(problem3Test);
        if (new HashSet<>(Arrays.asList(problem3Ans)).equals(new HashSet<>(Arrays.asList(javaCollections.removeDuplicateElements(temp))))) {
            problem3Score += 12.5;
        } else {
            Log.e("Problem 3", String.format("Input: %s. Expected Output: %s. Actual output: %s", Arrays.toString(problem3SourceATest), Arrays.toString(problem3SourceBTest), javaCollections.removeDuplicateElements(temp).toString()));
        }
        scoreList.add(problem3Score);
    }

    // Problem 4 Test
    private void testFour() {
        HashSet<String> temp1 = new HashSet<>(problem4TestA);
        HashSet<String> temp2 = new HashSet<>(problem4TestB);
        if (javaCollections.intersectionOfTwoSets(temp1, temp2).equals(problem4Ans)) {
            problem4Score += 12.5;
        } else {
            Log.e("Problem 4", String.format("Input: %s and %s. Expected Output: %s. Actual output: %s", Arrays.asList(problem4TestA), Arrays.asList(problem4TestB), Arrays.asList(problem4Ans), Arrays.asList(javaCollections.intersectionOfTwoSets(temp1, temp2))));
        }
        scoreList.add(problem4Score);
    }

    // Problem 5 Test
    private void testFive() {
        HashSet<Integer> temp1 = new HashSet<>(problem5TestA);
        HashSet<Integer> temp2 = new HashSet<>(problem5TestB);
        if (javaCollections.mergeTwoSets(temp1, temp2).equals(problem5Ans)) {
            problem5Score += 12.5;
        } else {
            Log.e("Problem 5", String.format("Input: %s and %s. Expected Output: %s. Actual output: %s", Arrays.asList(problem5TestA), Arrays.asList(problem5TestB), Arrays.asList(problem5Ans), Arrays.asList(javaCollections.mergeTwoSets(temp1, temp2))));
        }
        scoreList.add(problem5Score);
    }

    // Problem 6 Test
    private void testSix() {

        HashSet<Integer> temp = new HashSet<>(problem6Test);
        if (problem6Ans == javaCollections.averageOfSet(temp)) {
            problem6Score += 12.5;
        } else {
            Log.e("Problem 6", String.format("Input: %s. Expected Output: %f. Actual output: %f", Arrays.asList(problem6Test), problem6Ans, javaCollections.averageOfSet(temp)));
        }
        scoreList.add(problem6Score);
    }

    // Problem 7 Test
    private void testSeven() {
        HashMap<String, Integer> temp = new HashMap<>(problem7Test);
        if (problem7Ans.equals(javaCollections.mapValueToKey(temp, problem7Key, problem7Value))) {
            problem7Score += 12.5;
        } else {
            Log.e("Problem 7", String.format("Input: %s, %s, and %s. Expected Output: %s. Actual output: %s", Arrays.asList(problem7Test), problem7Key, problem7Value.toString(), Arrays.asList(problem7Ans), Arrays.asList(javaCollections.mapValueToKey(temp, problem7Key, problem7Value))));
        }
        scoreList.add(problem7Score);
    }

    // Problem 8 Test
    private void testEight() {
        String[][] temp = problem8Test.clone();
        if (problem8Ans.equals(javaCollections.arrayToHashMap(temp))) {
            problem8Score += 12.5;
        } else {
            Log.e("Problem 8", String.format("Input: %s. Expected Output: %s. Actual output: %s", Arrays.deepToString(problem8Test), Arrays.asList(problem8Ans), Arrays.asList(javaCollections.arrayToHashMap(temp))));
        }
        scoreList.add(problem8Score);
    }

    // Bonus Test
    private void testBonus() {
        String[][] temp = problemBonusTest.clone();
        for (int i = 0; i < problemBonusTest.length; i++) {

            if (new HashSet<>(Arrays.asList(problemBonusAns[i])).equals(new HashSet<>(Arrays.asList(javaCollections.probelmBonus(problemBonusTest[i][0], problemBonusTest[i][1]))))) {
                problemBonusScore += 2;
            } else {
                Log.e("Problem bonus", String.format("Input: %s. Expected Output: %s. Actual output: %s", Arrays.toString(problemBonusTest[i]), Arrays.toString(problemBonusAns[i]), Arrays.toString(javaCollections.probelmBonus(problemBonusTest[i][0], problemBonusTest[i][1]))));
            }
        }
        scoreList.add(problemBonusScore);
    }
}
