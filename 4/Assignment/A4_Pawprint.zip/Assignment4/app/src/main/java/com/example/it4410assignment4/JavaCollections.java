package com.example.it4410assignment4;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import java.util.Map;
import java.util.Arrays;

public class JavaCollections {

    /* Problem 1: Create an ArrayList from an Array.
     * Description: Given an array of String.
     *              Return an ArrayList contains all elements in the given Array.
     * Example:
     *   Input: {"Java", "Objective-C"}. Output: [Java, Objective-C].
     *   Input: {"Kotlin, "Swift""}.     Output: [Kotlin, Swift].
     */
    public ArrayList<String> createArrayListFromArray(String[] inputArray) {

		ArrayList<String> res = new ArrayList<>();
		return res;
    }

    /* Problem 2: Determine if two ArrayLists contain exactly the same elements.
     * Description: Given two ArrayLists of String.
     *              Return true/false.
     * Example:
     *   Input: ["a", "b", "c"], ["c", "b", "a"]. Output: true.
     *   Input: ["a", "b", "c"], ["a", "a", "c"]. Output: false.
     */
    public boolean sameElementsOfTwoLists(ArrayList<String> firstList, ArrayList<String> secondList) {

        return false;
    }

    /* Problem 3: Remove duplicate elements in an ArrayList.
     * Description: Given an ArrayList of Integer.
     *              Return an arrayList doesn't contain duplicate elements.
     * Example:
     *   Input: [1, 2, 3, 3].          Output: [1, 2, 3].
     *   Input: [1, 2, 2, 2, 3, 4, 5]. Output: [1, 2, 3, 4, 5].
     */
    public ArrayList<Integer> removeDuplicateElements(ArrayList<Integer> inputList) {

        ArrayList<Integer> res = new ArrayList<>();
        return res;
    }

    /* Problem 4: Find the intersection of two sets.
     * Description: Given two HashSets of String.
     *              Return a HashSet contains only the elements common to both HashSets.
     * Example:
     *   Input: [a, b ,c, d], [c, b ,a, f]. Output: [a, b, c].
     *   Input: [Hello, Hi, Goodbye], [Hi]. Output: [Hi].
     */
    public HashSet<String> intersectionOfTwoSets(HashSet<String>firstSet, HashSet<String>secondSet) {

        HashSet<String> res = new HashSet<>();
        return res;
    }

    /* Problem 5: Merge two sets.
     * Description: Given two HashSets of Integer.
     *              Return a HashSet contains the both elements
     * Example:
     *   Input: [2, 3, 6], [7, 1, 9]. Output: [2, 3, 6, 7, 1, 9].
     *   Input: [152, 6, 21], [3].    Output: [152, 6, 21, 3].
     */
    public HashSet<Integer> mergeTwoSets(HashSet<Integer> firstSet, HashSet<Integer> secondSet) {

        HashSet<Integer> res = new HashSet<>();
        return res;
    }

    /* Problem 6: Calculate the average of an Integer HashSet
     * Description: Given a HashSet of Integer.
     *              Return the average and round your answer to two decimal places.
     * Example:
     *   Input: [2 ,3].          Output: 2.50.
     *   Input: [1, 2, 3, 4, 5]. Output: 3.00.
     */
    public double averageOfSet(HashSet<Integer> inputSet) {

        return 0.00;

    }

    /* Problem 7: Map key to value.
     * Description: If the given key doesn't exist, insert a mapping(key to value) into the HashMap.
     *              If the given key exists but its value is different, replacing the previous value with the given value.
     *              If the given key exists and the given value is same as the value associated with the given key, return the original HashMap.
     *              Given a HashMap<String, Integer>, a key of String, a value of Integer.
     *              Return a HashMap.
     * Example:
     *   Input: {apple=10, orange=20}, "peach", 30. Output: {apple=10, orange=20, peach=30}.
     *   Input: {coke=5, pepsi=10}, "pepsi", 20.    Output: {coke=5, pepsi=20}.
     *   Input: {iPhone X=6, iPhone XS=8}, "iPhone X", 6. Output: {iPhone X=6, iPhone XS=8}.
     *   *Hint: This could be done with one step.
     */
    public HashMap<String, Integer> mapValueToKey(HashMap<String, Integer> inputMap, String inputKey, Integer inputValue) {

        HashMap<String, Integer> res = new HashMap<>();
        return res;
    }

    /* Problem 8: Convert 2D String Array to HashMap
     * Description: Given a 2D String Array (n by 2).
     *              Return a HashMap with keys and values (key: a[n][0], value: a[n][1]).
     *
     * Example:
     *   Input: {{"iPhone", "iOS"}, {"Pixel", "Android"}}. Output: {iPhone=iOS, Pixel=Android}.
     *   Input: {{"PUBG", "Bluehole"}, {"Dota 2", "Valve"}, {"LOL", "Riot"}}. Output: {PUBG=Bluehole, Dota 2=Valve, LOL=Riot}.
     */
    public HashMap<String, String> arrayToHashMap(String[][] input2DString) {

        HashMap<String, String> res = new HashMap<> ();
        return res;
    }

    /* Problem bonus: Find uncommon words from two sentences.
     * Description: Given two Strings.
     *              Each String contains multiple words. Each word is separated by a single space.
     *              Find uncommon words from two given Strings.
     *              Return a String Array that contains uncommon words.
     * Example:
     *   Input: "hello world", "hello new world". Output: ["new"].
     *   Input: "this is what I want", "this is what you want". Output: ["I", "you"].
     *   *Hint: Use HashSet or HashMap.
     */
    public String[] probelmBonus(String firstString, String secondsTRING) {

        String[] res = new String[1];
        return res;
    }
}