package edu.missouri.recyclerviewdemo1;

import android.content.Intent;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Menu;
import android.view.MenuItem;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private List<Food> foodList;
    private MyRecyclerViewAdapter myRecyclerViewAdapter;

    private static final int ADD_FOOD_REQUEST_CODE = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(MainActivity.this));
        foodList = new ArrayList<>();
        Food food1 = new Food("Avocados", 5);
        foodList.add(food1);
        Food food2 = new Food("Bananas", 6);
        foodList.add(food2);
        Food food3 = new Food("Blueberries", 7);
        foodList.add(food3);
        myRecyclerViewAdapter = new MyRecyclerViewAdapter(foodList);
        recyclerView.setAdapter(myRecyclerViewAdapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_add:
                Intent intent = new Intent(MainActivity.this, AddFoodActivity.class);
                startActivityForResult(intent, ADD_FOOD_REQUEST_CODE);
                return true;

            case R.id.action_delete:
                myRecyclerViewAdapter.deleteFood();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == ADD_FOOD_REQUEST_CODE && resultCode == RESULT_OK) {
            Food food = (Food) data.getSerializableExtra("FOOD_EXTRA");
            myRecyclerViewAdapter.addFood(food);
        }
    }
}
