package edu.missouri.recyclerviewdemo1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class AddFoodActivity extends AppCompatActivity {

    private EditText foodNameEditText;
    private EditText foodPriceEditText;
    private Button finishButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_food);

        foodNameEditText = findViewById(R.id.food_name_et);
        foodPriceEditText = findViewById(R.id.food_price_et);
        finishButton = findViewById(R.id.finish_btn);
        finishButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String foodName = foodNameEditText.getText().toString();
                double foodPrice = 0;
                try {
                    foodPrice = Double.parseDouble(foodPriceEditText.getText().toString());
                } catch (RuntimeException e) {
                    e.printStackTrace();
                }
                Food food = new Food(foodName, foodPrice);
                Intent intent = new Intent();
                intent.putExtra("FOOD_EXTRA", food);
                setResult(RESULT_OK, intent);
                finish();
            }
        });
    }
}
