package edu.missouri.recyclerviewdemo1;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

public class MyRecyclerViewAdapter extends RecyclerView.Adapter {

    private List<Food> foodList;

    public MyRecyclerViewAdapter(List<Food> foodList) {
        this.foodList = foodList;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater layoutInflater = LayoutInflater.from(viewGroup.getContext());
        View itemView = layoutInflater.inflate(R.layout.food_item, viewGroup, false);
        MyViewHolder myViewHolder = new MyViewHolder(itemView);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
        MyViewHolder myViewHolder = (MyViewHolder) viewHolder;
        Food food = foodList.get(i);
        myViewHolder.foodNameTextView.setText(food.getName());
        myViewHolder.foodPriceTextView.setText("$" + food.getPrice());
    }

    @Override
    public int getItemCount() {
        return foodList.size();
    }

    public void addFood(Food food) {
        foodList.add(food);
//        notifyDataSetChanged();
        notifyItemInserted(foodList.size() - 1);
    }

    public void deleteFood() {
        if (!foodList.isEmpty()) {
            foodList.remove(foodList.size() - 1);
//            notifyDataSetChanged();
            notifyItemRemoved(foodList.size());
        }
    }

    class MyViewHolder extends RecyclerView.ViewHolder {

        public TextView foodNameTextView;
        public TextView foodPriceTextView;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            foodNameTextView = itemView.findViewById(R.id.item_food_name_tv);
            foodPriceTextView = itemView.findViewById(R.id.item_food_price_tv);
        }
    }
}
