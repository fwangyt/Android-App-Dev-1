package edu.missouri.recyclerviewdemo1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private List<Food> foodList;
    private MyRecyclerViewAdapter myRecyclerViewAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(MainActivity.this));
        foodList = new ArrayList<>();
        Food food1 = new Food("Avocados", 5);
        foodList.add(food1);
        Food food2 = new Food("Bananas", 6);
        foodList.add(food2);
        Food food3 = new Food("Blueberries", 7);
        foodList.add(food3);
        myRecyclerViewAdapter = new MyRecyclerViewAdapter(foodList);
        recyclerView.setAdapter(myRecyclerViewAdapter);
    }
}
