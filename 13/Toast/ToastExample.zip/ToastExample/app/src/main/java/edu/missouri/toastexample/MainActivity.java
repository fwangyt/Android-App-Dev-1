package edu.missouri.toastexample;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private Button shortToastButton;
    private Button longToastButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        shortToastButton = findViewById(R.id.short_toast_btn);
        shortToastButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "This is a short Toast!", Toast.LENGTH_SHORT).show();
            }
        });
        longToastButton = findViewById(R.id.long_toast_btn);
        longToastButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "This is a long Toast!", Toast.LENGTH_LONG).show();
            }
        });
    }
}
