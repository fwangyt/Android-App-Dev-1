package com.example.mediaplayerexample1;

import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.io.IOException;

public class MainActivity extends AppCompatActivity {

    private Button playButton;
    private Button pauseButton;
    private Button stopButton;

    private MediaPlayer mediaPlayer;

    boolean hasStopped;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        playButton = findViewById(R.id.play_btn);
        playButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (hasStopped) {
                    try {
                        mediaPlayer.prepare();
                        hasStopped = false;
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                mediaPlayer.start();
            }
        });
        pauseButton = findViewById(R.id.pause_btn);
        pauseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!hasStopped) {
                    mediaPlayer.pause();
                }
            }
        });
        stopButton = findViewById(R.id.stop_btn);
        stopButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mediaPlayer.stop();
                hasStopped = true;
            }
        });

        mediaPlayer = MediaPlayer.create(this, R.raw.that_girl);
    }
}
