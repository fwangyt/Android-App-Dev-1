package edu.missouri.progressbarexample1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;

public class MainActivity extends AppCompatActivity {

    private ProgressBar progressBar;
    private Button displayButton;
    private Button hideButton;
    private Button addProgressButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        progressBar = findViewById(R.id.progressBar);
        displayButton = findViewById(R.id.display_progress_bar_btn);
        displayButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                progressBar.setVisibility(View.VISIBLE);
            }
        });
        hideButton = findViewById(R.id.hide_progress_bar_btn);
        hideButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                progressBar.setVisibility(View.INVISIBLE);
            }
        });
        addProgressButton = findViewById(R.id.add_progress_btn);
        addProgressButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                int newProgress = progressBar.getProgress() + 10;
//                progressBar.setProgress(newProgress);
                progressBar.incrementProgressBy(10);
            }
        });
    }
}
