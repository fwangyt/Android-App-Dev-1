package com.example.it4410assignment2;

import android.support.v4.content.res.TypedArrayUtils;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class MainActivity extends AppCompatActivity {


    /* ------------------------------------
     * -              TEST                -
     * -   DO NOT CHANGE THE CODE BELOW   -
     * ------------------------------------
     */
    private int[] problem1Tests = {90, 80, 70 ,60 ,0};
    private char[] problem1Answers = {'A', 'B', 'C', 'D', 'F'};
    private int[][] problem2Tests = {{1, 3}, {1, 10}, {1, 21}, {1, 50}, {1, 1000}};
    private int[] problem2Answers = {1, 3, 7, 16, 333};
    private int[][] problem3Tests = {{1, 5}, {2, 5}, {3, 0}, {5, 2}, {6, 11}};
    private double[] problem3Answers = {43.2, 73.7, 91.4, 157.5, 210.8};
    private char[][] problem4Tests = {{'A', 'B', 'C'}, {'A', 'b', 'C'}, {'a', 'b', 'C'}, {'a', 'b', 'c'}, {'A', 'b', 'C'}};
    private char[][] problem4Answers = {{'a', 'b', 'c'}, {'a', 'B', 'c'}, {'A', 'B', 'c'}, {'A', 'B', 'C'}, {'a', 'B', 'c'}};
    private int[][] problem5Tests = {{32, 16}, {11223, 1}, {319, 493}, {468598, 5631685}, {156, 485}};
    private int[] problem5Answers = {16, 1, 29, 67, 1};
    private long[] problem6Tests = {5731112222L, 5732223333L, 5733334444L, 5734445555L, 5735556666L};
    private String[] problem6Answers = {"(573)111-2222", "(573)222-3333", "(573)333-4444", "(573)444-5555", "(573)555-6666"};
    private Integer[][] problem7Tests = {{10, 2, 3, 9, 10, 10, 9, 10, 9}, {3, 4 ,5, 6, 2, 6}, {3, 4 ,5}, {2, 2, 2, 2, 3}, {3, 4 ,5 ,6 ,7 ,8, 7, 7}};
    private Integer[] problem7Answers = {9, 5, 4, 2, 7};
    private int[][] problem8Tests = {{1, 2, 3, 4, 5}, {2, 34, 23, 345, 43}, {12, 6, 23, 345, 243}, {0, 0, 1, 3, 4, 5}, {2, 5, 67, 23, 5}};
    private int[] problem8TestKeys = {9, 57, 18, 0, 10};
    private int[][] problem8Answers = {{4, 5}, {34, 23}, {12, 6}, {0, 0}, {5, 5}};
    private String[] problemBonusTests = {"I love Objective-C", "Mizzou EECS Dept. Includes CS ECE IT DS !", "Android App Development", "Minsi is my girl", "AI SUCKS !??"};
    private String[] problemBonusAnswers = {"I evol C-evitcejbO", "uozziM SCEE .tpeD sedulcnI SC ECE TI SD !", "diordnA ppA tnempoleveD", "isniM si ym lrig", "IA SKCUS ??!"};

    private double problem1Score = 0.0;
    private double problem2Score = 0.0;
    private double problem3Score = 0.0;
    private double problem4Score = 0.0;
    private double problem5Score = 0.0;
    private double problem6Score = 0.0;
    private double problem7Score = 0.0;
    private double problem8Score = 0.0;
    private double problemBonusScore = 0.0;
    private ArrayList<Double> scoreList = new ArrayList<>();

    private TextView problem1TextView;
    private TextView problem2TextView;
    private TextView problem3TextView;
    private TextView problem4TextView;
    private TextView problem5TextView;
    private TextView problem6TextView;
    private TextView problem7TextView;
    private TextView problem8TextView;
    private TextView problemBonusTextView;
    private TextView totalScoreTextView;
    private Button runButton;

    JavaBasics javaBasics = new JavaBasics();

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        runButton = findViewById(R.id.runButton);
        problem1TextView = findViewById(R.id.problem1TextView);
        problem2TextView = findViewById(R.id.problem2TextView);
        problem3TextView = findViewById(R.id.problem3TextView);
        problem4TextView = findViewById(R.id.problem4TextView);
        problem5TextView = findViewById(R.id.problem5TextView);
        problem6TextView = findViewById(R.id.problem6TextView);
        problem7TextView = findViewById(R.id.problem7TextView);
        problem8TextView = findViewById(R.id.problem8TextView);
        problemBonusTextView = findViewById(R.id.problemBonusTextView);
        totalScoreTextView = findViewById(R.id.totalScoreTextView);

        resetScore();

        // Button Click
        runButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                testOne();
                problem1TextView.setText(String.format("Problem 1 score: %.1f/12.5", problem1Score));

                testTwo();
                problem2TextView.setText(String.format("Problem 2 score: %.1f/12.5", problem2Score));

                testThree();
                problem3TextView.setText(String.format("Problem 3 score: %.1f/12.5", problem3Score));

                testFour();
                problem4TextView.setText(String.format("Problem 4 score: %.1f/12.5", problem4Score));

                testFive();
                problem5TextView.setText(String.format("Problem 5 score: %.1f/12.5", problem5Score));

                testSix();
                problem6TextView.setText(String.format("Problem 6 score: %.1f/12.5", problem6Score));

                testSeven();
                problem7TextView.setText(String.format("Problem 7 score: %.1f/12.5", problem7Score));

                testEight();
                problem8TextView.setText(String.format("Problem 8 score: %.1f/12.5", problem8Score));

                testBonus();
                problemBonusTextView.setText(String.format("Problem bonus score: %.1f/10.0", problemBonusScore));
                //double totalScore = scoreList.stream().mapToDouble(s -> s).sum();
                totalScoreTextView.setText(String.format("Total Score: %.1f/100.0", getTotalScore()));

                runButton.setEnabled(false);
            }
        });
    }

    private double getTotalScore() {
        double totalScore = 0.0;
        for (double score : scoreList) {
            totalScore += score;
        }
        return totalScore;
    }

    private void resetScore() {
        problem1Score = 0.0;
        problem2Score = 0.0;
        problem3Score = 0.0;
        problem4Score = 0.0;
        problem5Score = 0.0;
        problem6Score = 0.0;
        problem7Score = 0.0;
        problem8Score = 0.0;
        problemBonusScore = 0.0;
        scoreList.removeAll(scoreList);
    }

    // Problem 1 Test
    private void testOne() {

        for (int i = 0; i < problem1Tests.length; i++) {
            if (javaBasics.letterGrade(problem1Tests[i]) == problem1Answers[i]) {
                problem1Score += 2.5;
            } else {
                Log.e("Problem 1", String.format("Input: %d. Expected Output: %c. Actual output: %c", problem1Tests[i], problem1Answers[i], javaBasics.letterGrade(problem1Tests[i])));
            }
        }
        scoreList.add(problem1Score);
    }

    // Problem 2 Test
    private void testTwo() {

        for (int i = 0; i < problem2Tests.length; i++) {
            if (javaBasics.numbersAreDivisibleBy3(problem2Tests[i][0], problem2Tests[i][1]) == problem2Answers[i]) {
                problem2Score += 2.5;
            } else {
                Log.e("Problem 2", String.format("Input: %d, %d. Expected Output: %d. Actual output: %d", problem2Tests[i][0], problem2Tests[i][1], problem2Answers[i], javaBasics.numbersAreDivisibleBy3(problem2Tests[i][0], problem2Tests[i][1])));
            }
        }
        scoreList.add(problem2Score);
    }

    // Problem 3 Test
    private void testThree() {

        for (int i = 0; i < problem3Tests.length; i++) {
            if (javaBasics.heightConverter(problem3Tests[i][0], problem3Tests[i][1]) == problem3Answers[i]) {
                problem3Score += 2.5;
            } else {
                Log.e("Problem 3", String.format("Input: %d, %d. Expected Output: %f. Actual output: %f", problem3Tests[i][0], problem3Tests[i][1], problem3Answers[i], javaBasics.heightConverter(problem3Tests[i][0], problem3Tests[i][1])));
            }
        }
        scoreList.add(problem3Score);
    }

    // Problem 4 Test
    private void testFour() {

        for (int i = 0; i < problem4Tests.length; i++) {
            if (Arrays.equals(javaBasics.letterConvert(problem4Tests[i]), problem4Answers[i])) {
                problem4Score += 2.5;
            } else {
                Log.e("Problem 4", String.format("Input: %s. Expected Output: %s. Actual output: %s", Arrays.toString(problem4Tests[i]), Arrays.toString(problem4Answers[i]), Arrays.toString(javaBasics.letterConvert(problem4Tests[i]))));
            }
        }
        scoreList.add(problem4Score);
    }

    // Problem 5 Test
    private void testFive() {

        for (int i = 0; i < problem5Tests.length; i++) {
            if (javaBasics.gcdOfTwoNumber(problem5Tests[i][0], problem5Tests[i][1]) == problem5Answers[i]) {
                problem5Score += 2.5;
            } else {
                Log.e("Problem 5", String.format("Input: %d, %d. Expected Output: %d. Actual output: %d", problem5Tests[i][0], problem5Tests[i][1], problem5Answers[i], javaBasics.gcdOfTwoNumber(problem5Tests[i][0], problem5Tests[i][1])));
            }
        }
        scoreList.add(problem5Score);
    }

    // Problem 6 Test
    private void testSix() {

        for (int i = 0; i < problem6Tests.length; i++) {
            if (javaBasics.formatPhoneNumber(problem6Tests[i]).equals(problem6Answers[i])) {
                problem6Score += 2.5;
            } else {
                Log.e("Problem 6", String.format("Input: %d. Expected Output: %s. Actual output: %s", problem6Tests[i], problem6Answers[i], javaBasics.formatPhoneNumber(problem6Tests[i])));
            }
        }
        scoreList.add(problem6Score);
    }

    // Problem 7 Test
    private void testSeven() {

        for (int i = 0; i < problem7Tests.length; i++) {
            if (javaBasics.secondLargestNumber(problem7Tests[i]) == problem7Answers[i]) {
                problem7Score += 2.5;
            } else {
                Log.e("Problem 7", String.format("Input: %s. Expected Output: %d. Actual output: %d", Arrays.toString(problem7Tests[i]), problem7Answers[i], javaBasics.secondLargestNumber(problem7Tests[i])));
            }
        }
        scoreList.add(problem7Score);
    }

    // Problem 8 Test
    private void testEight() {

        for (int i = 0; i < problem8Tests.length; i++) {

            if (Arrays.equals(javaBasics.twoNumbersBySumKey(problem8Tests[i], problem8TestKeys[i]), problem8Answers[i])) {
                problem8Score += 2.5;
            } else {
                Log.e("Problem 8", String.format("Input: %s, %d. Expected Output: %s. Actual output: %s", Arrays.toString(problem8Tests[i]), problem8TestKeys[i],  Arrays.toString(problem8Answers[i]), Arrays.toString(javaBasics.twoNumbersBySumKey(problem8Tests[i], problem8TestKeys[i]))));
            }
        }
        scoreList.add(problem8Score);
    }

    // Bonus Test
    private void testBonus() {
        for (int i = 0; i < problemBonusTests.length; i++) {
            if (javaBasics.reverseWord(problemBonusTests[i]).equals(problemBonusAnswers[i])) {
                problemBonusScore += 2;
            } else {
                Log.e("Problem bonus", String.format("Input: %s. Expected Output: %s. Actual output: %s", problemBonusTests[i], problemBonusAnswers[i], javaBasics.reverseWord(problemBonusTests[i])));
            }
        }
        scoreList.add(problemBonusScore);
    }
}
