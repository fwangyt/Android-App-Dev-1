package com.example.it4410assignment2;

import java.util.Arrays;
import java.util.Collections;

public class JavaBasics {


    /* Problem 1: Convert a numerical grade to a letter grade.
     * Description: A->[90, 100]
     * 				B->[80, 90)
     * 				C->[70, 80)
     * 				D->[60, 70)
     * 				F->[0 , 60)
     * Example:
     *   Input: 90. Output: 'A'.
     *   Input: 75. Output: 'C'.
     */
    public char letterGrade(int grade) {

        return 'Z';
    }

    /* Problem 2: Find how many numbers between [m, n] are divisible by 3.
     * Description: Given m = 1, n = 3.
     * 				1 mod 3 = 1, 1 is not divisible by 3.
     * 				2 mod 3 = 2, 2 is not divisible by 3.
     * 				3 mod 3 = 0, 3 is divisible by 3.
     * 				There is only one number is divisible by 3 between [1, 3].
     * Example:
     *   Input: 1, 10. output: 3.
     *   Input: 1, 21. output: 7.
     */
    public int numbersAreDivisibleBy3(int m, int n) {

        return -1;
    }

    /* Problem 3: Convert feet(ft) and inches(in) to centimeters(cm)
     * Description: 1 ft = 30.48 cm
     * 				1 in = 2.54 cm
     * 				4 feet 6 inches	= 4(30.48) + 6(2.54) = 137.16 cm ~= 137.2 cm
     * 				***Round your output to one decimal place***
     * Example:
     *   Input: 5, 6. Output: 167.6
     *   Input: 6, 9. Output: 205.7
     */
    public double heightConverter(int feet, int inches) {

        return -1.0;
    }

    /* Problem 4: Convert characters to upper case/ lower case.
     * Description: Given an array of characters.
     * 				Convert the character to upper case if it is lower case.
     * 				Convert the character to lower case if it is upper case.
     * Example:
     *   Input: {'a', 'B', 'c'}. Output: {'A', 'b', 'C'}.
     *   Input: {'U', 'i', 'k'}. Output: {'u', 'I', 'K'}.
     */
    public char[] letterConvert(char[] letterArray) {

        return null;
    }

    /* Problem 5: Calculate the Greatest Common Divisor(GCD) of two numbers.
     * Description: Check "https://en.wikipedia.org/wiki/Greatest_common_divisor" for more details.
     * Example:
     *   Input: 55, 25. Output: 5.
     *   Input: 1, 33.  Output: 1.
     */
    public int gcdOfTwoNumber(int num1, int num2) {

        return -1;
    }

    /* Problem 6: Format a domestic phone number.
     * Description: Given a domestic phone number(integer type),
     * 				return a string with parenthesis/dash format.
     * Example:
     *   Input: 5736668888. Output: "(573)666-8888".
     *   Input: 5731117777. Output: "(573)111-7777".
     */
    public String formatPhoneNumber(long phoneNumber) {

        return "";
    }

    /* Problem 7: Find the second largest number in an array.
     * Description: Given an array of integer numbers, return the second largest number.
     * Example:
     *   Input: {2, 7, 3, 6, 8}. 		  Output: 7.
     *   Input: {10, 4, 6, 10, 6, 10, 9}. Output: 9.
     */
    public Integer secondLargestNumber(Integer[] nums) {

        return -1;
    }

    /* Problem 8: Find two numbers by a sum key.
     * Description: Given an array of integer numbers,
     * 				there must be two numbers such that they add up to a specific sum key.
     * 				Return an array of these two numbers.
     * 				*You may assume that each input would have exactly one solution.
     * Example:
     *   Input: {1, 2, 3, 4, 5}, 9. Output: {4, 5}.
     *   Input: {2, 5, 7, 4, 2}, 4. Output: {2, 2}.
     */
    public int[] twoNumbersBySumKey(int[] nums, int sumKey) {

        return null;
    }

    /* Problem bonus: Reverse each word in a string.
     * Description: Given a string that contains multiple words.
     * 				Each word is separated by a single space.
     * 				Reverse the order of characters in each word.
     * Example:
     *   Input: "I evol uoy".     Output: "I love you".
     * 	 Input: "Android vs iOS". Output: "diordnA sv SOi".
     */
    public String reverseWord(String s) {

        return "";
    }
}
