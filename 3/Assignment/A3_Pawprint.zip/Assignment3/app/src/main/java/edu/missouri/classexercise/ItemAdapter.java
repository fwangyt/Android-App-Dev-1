package edu.missouri.classexercise;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

public class ItemAdapter extends RecyclerView.Adapter {

    private List<Item> items;

    public ItemAdapter(List<Item> items) {
        this.items = items;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_item, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
        if (i >= items.size()) {
            return;
        }
        Item item = items.get(i);
        ViewHolder myViewHolder = (ViewHolder) viewHolder;
        myViewHolder.noTextView.setText("NO: " + item.getNo());
        myViewHolder.nameTextView.setText("Name: " + item.getName());
        myViewHolder.priceTextView.setText("Price: " + item.getPrice());
        myViewHolder.stockTextView.setText("Stock: " + item.getStock());
    }

    @Override
    public int getItemCount() {
        return items != null ? items.size() : 0;
    }

    class ViewHolder extends RecyclerView.ViewHolder {

        TextView noTextView;
        TextView nameTextView;
        TextView priceTextView;
        TextView stockTextView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            noTextView = itemView.findViewById(R.id.no_tv);
            nameTextView = itemView.findViewById(R.id.name_tv);
            priceTextView = itemView.findViewById(R.id.price_tv);
            stockTextView = itemView.findViewById(R.id.stock_tv);
        }
    }
}
