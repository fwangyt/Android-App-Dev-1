package edu.missouri.classexercise;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AddItemActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText noEditText;
    private EditText nameEditText;
    private EditText priceEditText;
    private EditText stockEditText;
    private Button finishButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        noEditText = findViewById(R.id.no_et);
        nameEditText = findViewById(R.id.name_et);
        priceEditText = findViewById(R.id.price_et);
        stockEditText = findViewById(R.id.stock_et);
        finishButton = findViewById(R.id.finish_btn);
        finishButton.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        String errorMsg = checkEmptyFields();
        if (!"".equals(errorMsg)) {
            Toast.makeText(this, errorMsg, Toast.LENGTH_SHORT).show();
            return;
        }
        Item item = new Item();
        String no = noEditText.getText().toString();
        String name = nameEditText.getText().toString();
        double price = Double.valueOf(priceEditText.getText().toString());
        int stock = Integer.valueOf(stockEditText.getText().toString());
        item.setNo(no);
        item.setName(name);
        item.setPrice(price);
        item.setStock(stock);
        Intent intent = new Intent();
        intent.putExtra("ITEM", item);
        setResult(RESULT_OK, intent);
        finish();
    }

    private String checkEmptyFields() {
        if (noEditText.getText().toString().isEmpty()) {
            return "Item No Cannot be Empty!";
        }
        if (nameEditText.getText().toString().isEmpty()) {
            return "Item Name Cannot be Empty!";
        }
        if (priceEditText.getText().toString().isEmpty()) {
            return "Item Price Cannot be Empty!";
        }
        if (stockEditText.getText().toString().isEmpty()) {
            return "Item Stock Cannot be Empty!";
        }
        try {
            Double.valueOf(priceEditText.getText().toString());
        } catch (RuntimeException e) {
            return "Item Price Must be a Number";
        }
        try {
            Integer.valueOf(stockEditText.getText().toString());
        } catch (RuntimeException e) {
            return "Item Price Must be an Integer Number";
        }

        return "";
    }
}
