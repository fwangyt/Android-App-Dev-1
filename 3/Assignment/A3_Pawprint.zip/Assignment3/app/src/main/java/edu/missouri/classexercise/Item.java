package edu.missouri.classexercise;

import java.io.Serializable;

public class Item implements Serializable {
    
}
