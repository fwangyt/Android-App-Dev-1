package edu.missouri.classexercise;

import android.content.Intent;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final int ADD_CATEGORY = 1;
    private static final int SHOW_ITEM_LIST = 2;

    private int lastSelectedIndex = -1;

    private TextView statusTextView;
    private RecyclerView categoryRecyclerView;
    private CategoryAdapter categoryAdapter;
    private List<Category> categories;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        statusTextView = findViewById(R.id.ststus_tv);
        initData();
        categoryAdapter = new CategoryAdapter(categories);
        categoryAdapter.setOnItemClickListener(new CategoryAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
                Intent intent = new Intent(MainActivity.this, ItemListActivity.class);
                intent.putExtra("CATEGORY", categories.get(position));
                lastSelectedIndex =  position;
                startActivityForResult(intent, SHOW_ITEM_LIST);
            }
        });
        categoryRecyclerView = findViewById(R.id.category_recyclerview);
        categoryRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        categoryRecyclerView.setAdapter(categoryAdapter);
    }

    private void initData() {
        categories = new ArrayList<>();
        Category category1 = new Category("Food");
        Item item1 = new Item("12345", "Apple", 2.0, 10);
        Item item2 = new Item("54321", "Fruit", 4.0, 20);
        category1.addItem(item1);
        category1.addItem(item2);
        categories.add(category1);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menu_add:
                Intent intent = new Intent(this, AddCategoryActivity.class);
                startActivityForResult(intent, ADD_CATEGORY);
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if (requestCode == ADD_CATEGORY && resultCode == RESULT_OK) {
            String categoryName = data.getStringExtra("CATEGORY_NAME");
            if (categoryName == null) {
                return;
            }
            Category category = new Category(categoryName);
            categories.add(category);
            categoryAdapter.notifyItemInserted(categories.size() - 1);
            return;
        }
        if (requestCode == SHOW_ITEM_LIST) {
            try {
                Category category = (Category) data.getSerializableExtra("CATEGORY");
                if (category != null) {
                    categories.set(lastSelectedIndex, category);
                    categoryAdapter.notifyItemChanged(lastSelectedIndex);
                }
                lastSelectedIndex = -1;
            } catch (RuntimeException e) {
            }
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }
}
