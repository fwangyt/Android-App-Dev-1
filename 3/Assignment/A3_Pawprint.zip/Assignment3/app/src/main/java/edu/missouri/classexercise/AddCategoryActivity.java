package edu.missouri.classexercise;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AddCategoryActivity extends AppCompatActivity {

    private EditText categoryNameEditText;
    private Button finishButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_category);

        categoryNameEditText = findViewById(R.id.category_name_tv);
        finishButton = findViewById(R.id.finish_btn);
        finishButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if ("".equals(categoryNameEditText.getText().toString())) {
                    Toast.makeText(AddCategoryActivity.this, "Category Name Cannot be Empty!", Toast.LENGTH_SHORT).show();
                    return;
                }
                Intent intent = new Intent();
                intent.putExtra("CATEGORY_NAME", categoryNameEditText.getText().toString());
                setResult(RESULT_OK, intent);
                finish();
            }
        });
    }
}
