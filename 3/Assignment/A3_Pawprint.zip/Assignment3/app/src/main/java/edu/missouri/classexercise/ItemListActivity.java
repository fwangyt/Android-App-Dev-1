package edu.missouri.classexercise;

import android.content.Intent;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

public class ItemListActivity extends AppCompatActivity {

    private static final int ADD_ITEM = 1;

    private Category category;

    private TextView categoryNameTextView;
    private RecyclerView itemRecyclerView;

    private ItemAdapter itemAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_list);

        category = (Category) getIntent().getSerializableExtra("CATEGORY");
        if (category == null) {
            return;
        }
        categoryNameTextView = findViewById(R.id.category_name_tv);
        categoryNameTextView.setText(category.getName());
        itemRecyclerView = findViewById(R.id.item_recyclerview);
        itemAdapter = new ItemAdapter(category.getItems());
        itemRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        itemRecyclerView.setAdapter(itemAdapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_item_list, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menu_add:
                Intent intent = new Intent(this, AddItemActivity.class);
                startActivityForResult(intent, ADD_ITEM);
        }
        return super.onOptionsItemSelected(item);
    }

    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if (requestCode == ADD_ITEM && resultCode == RESULT_OK) {
            Item item = (Item) data.getSerializableExtra("ITEM");
            if (item == null) {
                return;
            }
            category.addItem(item);
            itemAdapter.notifyItemInserted(category.getItemCount() - 1);
            Intent intent = new Intent();
            intent.putExtra("CATEGORY", category);
            setResult(RESULT_OK, intent);
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }
}
